-- MySQL dump 10.13  Distrib 8.0.26, for Linux (x86_64)
--
-- Host: localhost    Database: dispatch
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '3ec0b44f-ead5-11eb-9e9a-005056bf7f6d:1-28459527,
f84b8d75-ead5-11eb-a3bd-005056bfebb7:1-5843651';

--
-- Current Database: `dispatch`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `dispatch` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `dispatch`;

--
-- Table structure for table `crontab_job_list`
--

DROP TABLE IF EXISTS `crontab_job_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crontab_job_list` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `min` tinyint NOT NULL DEFAULT '0',
  `hour` tinyint NOT NULL DEFAULT '-1',
  `day` tinyint unsigned NOT NULL DEFAULT '0',
  `month` tinyint unsigned NOT NULL DEFAULT '0',
  `week` tinyint NOT NULL DEFAULT '-1',
  `shell` varchar(500) NOT NULL DEFAULT '',
  `status` tinyint NOT NULL DEFAULT '0',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_transport_logs`
--

DROP TABLE IF EXISTS `data_transport_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_transport_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `transport_type` tinyint unsigned NOT NULL DEFAULT '0',
  `transport_data` varchar(2000) NOT NULL DEFAULT '',
  `response_result` varchar(500) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43316 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `detection_job_finish`
--

DROP TABLE IF EXISTS `detection_job_finish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detection_job_finish` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `srcip` varchar(15) NOT NULL DEFAULT '',
  `src_nid` int unsigned NOT NULL DEFAULT '0',
  `src_node_name` varchar(100) NOT NULL DEFAULT '',
  `dstip` varchar(15) NOT NULL DEFAULT '',
  `dst_nid` int unsigned NOT NULL DEFAULT '0',
  `dst_node_name` varchar(100) NOT NULL DEFAULT '',
  `session` varchar(32) NOT NULL DEFAULT '',
  `rtt` int unsigned NOT NULL DEFAULT '0',
  `loss` decimal(5,2) NOT NULL DEFAULT '0.00',
  `req_result` varchar(1000) NOT NULL DEFAULT '',
  `fail_reason` varchar(500) NOT NULL DEFAULT '',
  `status` tinyint NOT NULL DEFAULT '2',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42620 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `detection_job_list`
--

DROP TABLE IF EXISTS `detection_job_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detection_job_list` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `srcip` varchar(15) NOT NULL DEFAULT '',
  `src_nid` int unsigned NOT NULL DEFAULT '0',
  `src_node_name` varchar(100) NOT NULL DEFAULT '',
  `dstip` varchar(15) NOT NULL DEFAULT '',
  `dst_nid` int unsigned NOT NULL DEFAULT '0',
  `dst_node_name` varchar(100) NOT NULL DEFAULT '',
  `length` int unsigned NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `status` tinyint NOT NULL DEFAULT '0',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44920 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `localr_notify`
--

DROP TABLE IF EXISTS `localr_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `localr_notify` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `pubip` varchar(15) NOT NULL DEFAULT '',
  `port` smallint unsigned NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `last_notify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unique` (`appid`,`stream_name`,`room_name`,`server_type`,`pubip`,`port`),
  KEY `idx_update_time` (`last_notify_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='本地中转和watchr通知状态表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `localr_request_logs`
--

DROP TABLE IF EXISTS `localr_request_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `localr_request_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `pubip` varchar(15) NOT NULL DEFAULT '',
  `port` smallint unsigned NOT NULL DEFAULT '0',
  `appid` varchar(1000) NOT NULL DEFAULT '',
  `stream_name` varchar(1000) NOT NULL DEFAULT '',
  `room_name` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='调度服务通知本地中转请求日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `node_detection_route`
--

DROP TABLE IF EXISTS `node_detection_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `node_detection_route` (
  `cid` int unsigned NOT NULL DEFAULT '0',
  `srcip` varchar(15) NOT NULL DEFAULT '',
  `src_innerip` varchar(15) NOT NULL DEFAULT '',
  `src_nid` int unsigned NOT NULL DEFAULT '0',
  `src_node_name` varchar(100) NOT NULL DEFAULT '',
  `dstip` varchar(15) NOT NULL DEFAULT '',
  `dst_innerip` varchar(15) NOT NULL DEFAULT '',
  `dst_nid` int unsigned NOT NULL DEFAULT '0',
  `dst_node_name` varchar(100) NOT NULL DEFAULT '',
  `status` tinyint NOT NULL DEFAULT '0',
  `rtt` int unsigned NOT NULL DEFAULT '0',
  `loss` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `ispnum` tinyint unsigned NOT NULL DEFAULT '0',
  `charge_rate` decimal(4,2) unsigned NOT NULL DEFAULT '1.00',
  `lastjob_ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cid`),
  KEY `index_route` (`srcip`,`dstip`),
  KEY `idx_node_detection_route` (`src_nid`,`dst_nid`,`status`,`rtt`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `node_detection_route_tmp`
--

DROP TABLE IF EXISTS `node_detection_route_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `node_detection_route_tmp` (
  `cid` int unsigned NOT NULL DEFAULT '0',
  `srcip` varchar(15) NOT NULL DEFAULT '',
  `src_innerip` varchar(15) NOT NULL DEFAULT '',
  `src_nid` int unsigned NOT NULL DEFAULT '0',
  `src_node_name` varchar(100) NOT NULL DEFAULT '',
  `dstip` varchar(15) NOT NULL DEFAULT '',
  `dst_innerip` varchar(15) NOT NULL DEFAULT '',
  `dst_nid` int unsigned NOT NULL DEFAULT '0',
  `dst_node_name` varchar(100) NOT NULL DEFAULT '',
  `status` tinyint NOT NULL DEFAULT '0',
  `rtt` int unsigned NOT NULL DEFAULT '0',
  `loss` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `ispnum` tinyint unsigned NOT NULL DEFAULT '0',
  `charge_rate` decimal(4,2) unsigned NOT NULL DEFAULT '1.00',
  `lastjob_ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cid`),
  KEY `index_route` (`srcip`,`dstip`),
  KEY `idx_node_detection_route_tmp` (`src_nid`,`dst_nid`,`status`,`rtt`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `node_info_local`
--

DROP TABLE IF EXISTS `node_info_local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `node_info_local` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `pubip` varchar(15) NOT NULL DEFAULT '',
  `webport` smallint unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `node_list`
--

DROP TABLE IF EXISTS `node_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `node_list` (
  `cid` int unsigned NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `node_name` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cid`),
  KEY `idx_node_list_name` (`node_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `node_list_tmp`
--

DROP TABLE IF EXISTS `node_list_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `node_list_tmp` (
  `cid` int unsigned NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `node_name` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cid`),
  KEY `idx_node_tmp_list_name` (`node_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `node_service_list`
--

DROP TABLE IF EXISTS `node_service_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `node_service_list` (
  `cid` int unsigned NOT NULL DEFAULT '1',
  `nid` int unsigned NOT NULL DEFAULT '0',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `pubip` varchar(15) NOT NULL DEFAULT '',
  `ispnum` tinyint unsigned NOT NULL DEFAULT '0',
  `port` smallint unsigned NOT NULL DEFAULT '0',
  `webport` smallint unsigned NOT NULL DEFAULT '0',
  `bindip` varchar(100) NOT NULL DEFAULT '',
  `origin_ip` varchar(100) NOT NULL DEFAULT '',
  `quota_total` int unsigned NOT NULL DEFAULT '0',
  `quota_used` int unsigned NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `build` varchar(100) NOT NULL DEFAULT '',
  `buildinfo` varchar(500) NOT NULL DEFAULT '',
  `service_ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cid`),
  KEY `idx_node_service_list_status` (`status`),
  KEY `idx_node_service_list_pubip` (`pubip`),
  KEY `idx_node_service_list_servertype` (`server_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `node_service_list_tmp`
--

DROP TABLE IF EXISTS `node_service_list_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `node_service_list_tmp` (
  `cid` int unsigned NOT NULL DEFAULT '1',
  `nid` int unsigned NOT NULL DEFAULT '0',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `pubip` varchar(15) NOT NULL DEFAULT '',
  `ispnum` tinyint unsigned NOT NULL DEFAULT '0',
  `port` smallint unsigned NOT NULL DEFAULT '0',
  `webport` smallint unsigned NOT NULL DEFAULT '0',
  `bindip` varchar(100) NOT NULL DEFAULT '',
  `origin_ip` varchar(100) NOT NULL DEFAULT '',
  `quota_total` int unsigned NOT NULL DEFAULT '0',
  `quota_used` int unsigned NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `build` varchar(100) NOT NULL DEFAULT '',
  `buildinfo` varchar(500) NOT NULL DEFAULT '',
  `service_ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cid`),
  KEY `idx_node_service_list_tmp_servertype` (`server_type`),
  KEY `idx_node_service_list_tmp_pubip` (`pubip`),
  KEY `idx_node_service_list_tmp_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `node_stream_list`
--

DROP TABLE IF EXISTS `node_stream_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `node_stream_list` (
  `cid` int unsigned NOT NULL DEFAULT '0',
  `nid` int unsigned NOT NULL DEFAULT '0',
  `appid` varchar(1000) NOT NULL DEFAULT '',
  `stream_name` varchar(1000) NOT NULL DEFAULT '',
  `room_name` varchar(1000) NOT NULL DEFAULT '',
  `roomid` varchar(1000) NOT NULL DEFAULT '',
  `uidstring` varchar(1000) NOT NULL DEFAULT '',
  `uid` varchar(1000) NOT NULL DEFAULT '',
  `fromip` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(100) NOT NULL DEFAULT '',
  `publish_port` int NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `stream_ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `node_stream_list_tmp`
--

DROP TABLE IF EXISTS `node_stream_list_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `node_stream_list_tmp` (
  `cid` int unsigned NOT NULL DEFAULT '0',
  `nid` int unsigned NOT NULL DEFAULT '0',
  `appid` varchar(1000) NOT NULL DEFAULT '',
  `stream_name` varchar(1000) NOT NULL DEFAULT '',
  `room_name` varchar(1000) NOT NULL DEFAULT '',
  `roomid` varchar(1000) NOT NULL DEFAULT '',
  `uidstring` varchar(1000) NOT NULL DEFAULT '',
  `uid` varchar(1000) NOT NULL DEFAULT '',
  `fromip` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(100) NOT NULL DEFAULT '',
  `publish_port` int NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `stream_ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_data_save`
--

DROP TABLE IF EXISTS `redirect_request_data_save`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_data_save` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `logs_id` bigint unsigned NOT NULL,
  `register_center_local` longtext NOT NULL,
  `node_service_list` longtext NOT NULL,
  `node_detection_route` longtext NOT NULL,
  `stream_list_local` longtext NOT NULL,
  `stream_list_watching` longtext NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs`
--

DROP TABLE IF EXISTS `redirect_request_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211022`
--

DROP TABLE IF EXISTS `redirect_request_logs20211022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211022` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211023`
--

DROP TABLE IF EXISTS `redirect_request_logs20211023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211023` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211024`
--

DROP TABLE IF EXISTS `redirect_request_logs20211024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211024` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211025`
--

DROP TABLE IF EXISTS `redirect_request_logs20211025`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211025` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211026`
--

DROP TABLE IF EXISTS `redirect_request_logs20211026`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211026` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211027`
--

DROP TABLE IF EXISTS `redirect_request_logs20211027`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211027` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211028`
--

DROP TABLE IF EXISTS `redirect_request_logs20211028`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211028` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211029`
--

DROP TABLE IF EXISTS `redirect_request_logs20211029`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211029` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211030`
--

DROP TABLE IF EXISTS `redirect_request_logs20211030`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211030` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211031`
--

DROP TABLE IF EXISTS `redirect_request_logs20211031`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211031` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211101`
--

DROP TABLE IF EXISTS `redirect_request_logs20211101`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211101` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211102`
--

DROP TABLE IF EXISTS `redirect_request_logs20211102`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211102` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211103`
--

DROP TABLE IF EXISTS `redirect_request_logs20211103`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211103` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211104`
--

DROP TABLE IF EXISTS `redirect_request_logs20211104`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211104` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211105`
--

DROP TABLE IF EXISTS `redirect_request_logs20211105`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211105` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211106`
--

DROP TABLE IF EXISTS `redirect_request_logs20211106`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211106` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211107`
--

DROP TABLE IF EXISTS `redirect_request_logs20211107`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211107` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211108`
--

DROP TABLE IF EXISTS `redirect_request_logs20211108`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211108` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211109`
--

DROP TABLE IF EXISTS `redirect_request_logs20211109`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211109` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211110`
--

DROP TABLE IF EXISTS `redirect_request_logs20211110`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211110` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211111`
--

DROP TABLE IF EXISTS `redirect_request_logs20211111`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211111` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211112`
--

DROP TABLE IF EXISTS `redirect_request_logs20211112`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211112` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211113`
--

DROP TABLE IF EXISTS `redirect_request_logs20211113`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211113` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211114`
--

DROP TABLE IF EXISTS `redirect_request_logs20211114`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211114` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211115`
--

DROP TABLE IF EXISTS `redirect_request_logs20211115`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211115` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211116`
--

DROP TABLE IF EXISTS `redirect_request_logs20211116`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211116` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211117`
--

DROP TABLE IF EXISTS `redirect_request_logs20211117`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211117` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211118`
--

DROP TABLE IF EXISTS `redirect_request_logs20211118`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211118` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211119`
--

DROP TABLE IF EXISTS `redirect_request_logs20211119`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211119` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redirect_request_logs20211120`
--

DROP TABLE IF EXISTS `redirect_request_logs20211120`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirect_request_logs20211120` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` tinyint unsigned NOT NULL DEFAULT '0',
  `act` tinyint NOT NULL DEFAULT '0',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint unsigned NOT NULL DEFAULT '0',
  `ts` varchar(100) NOT NULL DEFAULT '',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `clienttype` varchar(100) NOT NULL DEFAULT '',
  `error_code` smallint NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `server_allocate` varchar(1000) NOT NULL DEFAULT '',
  `log_allocate` longtext NOT NULL,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`appid`),
  KEY `idx_stream_name` (`stream_name`),
  KEY `idx_room_name` (`room_name`),
  KEY `idx_source` (`source`),
  KEY `idx_act` (`act`),
  KEY `idx_roomid` (`roomid`),
  KEY `idx_publish_ip` (`publish_ip`),
  KEY `idx_clienttype` (`clienttype`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_center_local`
--

DROP TABLE IF EXISTS `register_center_local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_center_local` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `pubip` varchar(15) NOT NULL DEFAULT '',
  `ispnum` tinyint unsigned NOT NULL DEFAULT '0',
  `bindip` varchar(100) NOT NULL DEFAULT '',
  `port` smallint unsigned NOT NULL DEFAULT '0',
  `webport` smallint unsigned NOT NULL DEFAULT '0',
  `innerip` varchar(100) NOT NULL DEFAULT '',
  `origin_ip` varchar(100) NOT NULL DEFAULT '',
  `mapip` varchar(200) NOT NULL DEFAULT '',
  `outputip` varchar(15) NOT NULL DEFAULT '',
  `quota_total` int unsigned NOT NULL DEFAULT '0',
  `quota_used` int unsigned NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `build` varchar(100) NOT NULL DEFAULT '',
  `buildinfo` varchar(500) NOT NULL DEFAULT '',
  `appname` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `index_servertype` (`server_type`),
  KEY `idx_register_center_local_pubip` (`pubip`),
  KEY `idx_register_center_local_port` (`port`)
) ENGINE=InnoDB AUTO_INCREMENT=34536 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_center_local_del_log`
--

DROP TABLE IF EXISTS `register_center_local_del_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_center_local_del_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `pubip` varchar(15) NOT NULL DEFAULT '',
  `ispnum` tinyint unsigned NOT NULL DEFAULT '0',
  `port` smallint unsigned NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `buildinfo` varchar(500) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `delete_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_update_time` (`update_time`),
  KEY `idx_del_time` (`delete_time`),
  KEY `idx_server_info` (`server_type`,`pubip`,`port`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_center_local_log`
--

DROP TABLE IF EXISTS `register_center_local_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_center_local_log` (
  `id` bigint unsigned NOT NULL,
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `pubip` varchar(15) NOT NULL DEFAULT '',
  `ispnum` tinyint unsigned NOT NULL DEFAULT '0',
  `bindip` varchar(100) NOT NULL DEFAULT '',
  `port` smallint unsigned NOT NULL DEFAULT '0',
  `webport` smallint unsigned NOT NULL DEFAULT '0',
  `innerip` varchar(100) NOT NULL DEFAULT '',
  `origin_ip` varchar(100) NOT NULL DEFAULT '',
  `quota_total` int unsigned NOT NULL DEFAULT '0',
  `quota_used` int unsigned NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `build` varchar(100) NOT NULL DEFAULT '',
  `buildinfo` varchar(500) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL,
  `update_time` timestamp NOT NULL,
  `delete_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `index_servertype` (`server_type`),
  KEY `delete_time` (`delete_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs`
--

DROP TABLE IF EXISTS `register_request_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20210914`
--

DROP TABLE IF EXISTS `register_request_logs20210914`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20210914` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB AUTO_INCREMENT=103645 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211022`
--

DROP TABLE IF EXISTS `register_request_logs20211022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211022` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB AUTO_INCREMENT=153863 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211023`
--

DROP TABLE IF EXISTS `register_request_logs20211023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211023` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211024`
--

DROP TABLE IF EXISTS `register_request_logs20211024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211024` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211025`
--

DROP TABLE IF EXISTS `register_request_logs20211025`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211025` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211026`
--

DROP TABLE IF EXISTS `register_request_logs20211026`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211026` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211027`
--

DROP TABLE IF EXISTS `register_request_logs20211027`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211027` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211028`
--

DROP TABLE IF EXISTS `register_request_logs20211028`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211028` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211029`
--

DROP TABLE IF EXISTS `register_request_logs20211029`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211029` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211030`
--

DROP TABLE IF EXISTS `register_request_logs20211030`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211030` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211031`
--

DROP TABLE IF EXISTS `register_request_logs20211031`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211031` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211101`
--

DROP TABLE IF EXISTS `register_request_logs20211101`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211101` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211102`
--

DROP TABLE IF EXISTS `register_request_logs20211102`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211102` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211103`
--

DROP TABLE IF EXISTS `register_request_logs20211103`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211103` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211104`
--

DROP TABLE IF EXISTS `register_request_logs20211104`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211104` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211105`
--

DROP TABLE IF EXISTS `register_request_logs20211105`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211105` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211106`
--

DROP TABLE IF EXISTS `register_request_logs20211106`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211106` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211107`
--

DROP TABLE IF EXISTS `register_request_logs20211107`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211107` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211108`
--

DROP TABLE IF EXISTS `register_request_logs20211108`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211108` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211109`
--

DROP TABLE IF EXISTS `register_request_logs20211109`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211109` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211110`
--

DROP TABLE IF EXISTS `register_request_logs20211110`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211110` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211111`
--

DROP TABLE IF EXISTS `register_request_logs20211111`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211111` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211112`
--

DROP TABLE IF EXISTS `register_request_logs20211112`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211112` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211113`
--

DROP TABLE IF EXISTS `register_request_logs20211113`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211113` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211114`
--

DROP TABLE IF EXISTS `register_request_logs20211114`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211114` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211115`
--

DROP TABLE IF EXISTS `register_request_logs20211115`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211115` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211116`
--

DROP TABLE IF EXISTS `register_request_logs20211116`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211116` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211117`
--

DROP TABLE IF EXISTS `register_request_logs20211117`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211117` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211118`
--

DROP TABLE IF EXISTS `register_request_logs20211118`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211118` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211119`
--

DROP TABLE IF EXISTS `register_request_logs20211119`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211119` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_request_logs20211120`
--

DROP TABLE IF EXISTS `register_request_logs20211120`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_request_logs20211120` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs`
--

DROP TABLE IF EXISTS `request_error_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20210914`
--

DROP TABLE IF EXISTS `request_error_logs20210914`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20210914` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211022`
--

DROP TABLE IF EXISTS `request_error_logs20211022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211022` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211023`
--

DROP TABLE IF EXISTS `request_error_logs20211023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211023` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211024`
--

DROP TABLE IF EXISTS `request_error_logs20211024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211024` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211025`
--

DROP TABLE IF EXISTS `request_error_logs20211025`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211025` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211026`
--

DROP TABLE IF EXISTS `request_error_logs20211026`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211026` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211027`
--

DROP TABLE IF EXISTS `request_error_logs20211027`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211027` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211028`
--

DROP TABLE IF EXISTS `request_error_logs20211028`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211028` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211029`
--

DROP TABLE IF EXISTS `request_error_logs20211029`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211029` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211030`
--

DROP TABLE IF EXISTS `request_error_logs20211030`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211030` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211031`
--

DROP TABLE IF EXISTS `request_error_logs20211031`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211031` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211101`
--

DROP TABLE IF EXISTS `request_error_logs20211101`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211101` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211102`
--

DROP TABLE IF EXISTS `request_error_logs20211102`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211102` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211103`
--

DROP TABLE IF EXISTS `request_error_logs20211103`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211103` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211104`
--

DROP TABLE IF EXISTS `request_error_logs20211104`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211104` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211105`
--

DROP TABLE IF EXISTS `request_error_logs20211105`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211105` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211106`
--

DROP TABLE IF EXISTS `request_error_logs20211106`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211106` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211107`
--

DROP TABLE IF EXISTS `request_error_logs20211107`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211107` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211108`
--

DROP TABLE IF EXISTS `request_error_logs20211108`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211108` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211109`
--

DROP TABLE IF EXISTS `request_error_logs20211109`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211109` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211110`
--

DROP TABLE IF EXISTS `request_error_logs20211110`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211110` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211111`
--

DROP TABLE IF EXISTS `request_error_logs20211111`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211111` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211112`
--

DROP TABLE IF EXISTS `request_error_logs20211112`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211112` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211113`
--

DROP TABLE IF EXISTS `request_error_logs20211113`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211113` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211114`
--

DROP TABLE IF EXISTS `request_error_logs20211114`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211114` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211115`
--

DROP TABLE IF EXISTS `request_error_logs20211115`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211115` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211116`
--

DROP TABLE IF EXISTS `request_error_logs20211116`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211116` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211117`
--

DROP TABLE IF EXISTS `request_error_logs20211117`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211117` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211118`
--

DROP TABLE IF EXISTS `request_error_logs20211118`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211118` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211119`
--

DROP TABLE IF EXISTS `request_error_logs20211119`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211119` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_error_logs20211120`
--

DROP TABLE IF EXISTS `request_error_logs20211120`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_error_logs20211120` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `request_type` tinyint NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `error_msg` varchar(100) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_list_del_log`
--

DROP TABLE IF EXISTS `stream_list_del_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_list_del_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` bigint unsigned NOT NULL DEFAULT '0',
  `pubip` varchar(15) NOT NULL DEFAULT '',
  `port` smallint unsigned NOT NULL DEFAULT '0',
  `server_type` varchar(100) NOT NULL DEFAULT '',
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `roomid` varchar(100) NOT NULL DEFAULT '',
  `uidstring` varchar(100) NOT NULL DEFAULT '',
  `uid` varchar(100) NOT NULL DEFAULT '0',
  `source` tinyint NOT NULL DEFAULT '0',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `delete_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `index_stream_common` (`appid`,`stream_name`,`room_name`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_update_time` (`update_time`),
  KEY `idx_del_time` (`delete_time`)
) ENGINE=InnoDB AUTO_INCREMENT=332 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_list_local`
--

DROP TABLE IF EXISTS `stream_list_local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_list_local` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `r_ip` varchar(15) NOT NULL DEFAULT '',
  `port` smallint unsigned NOT NULL DEFAULT '0',
  `server_type` varchar(100) NOT NULL DEFAULT '',
  `pubip` varchar(15) NOT NULL DEFAULT '',
  `innerip` varchar(15) NOT NULL DEFAULT '',
  `webport` smallint unsigned NOT NULL DEFAULT '0',
  `appid` varchar(1000) NOT NULL DEFAULT '',
  `stream_name` varchar(1000) NOT NULL DEFAULT '',
  `room_name` varchar(1000) NOT NULL DEFAULT '',
  `roomid` varchar(1000) NOT NULL DEFAULT '',
  `uidstring` varchar(1000) NOT NULL DEFAULT '',
  `uid` varchar(1000) NOT NULL DEFAULT '0',
  `serverip` varchar(100) NOT NULL DEFAULT '',
  `clientip` varchar(100) NOT NULL DEFAULT '',
  `status` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `fromip` varchar(500) NOT NULL DEFAULT '',
  `bitrate` int unsigned NOT NULL DEFAULT '0',
  `bitrate_rt` int unsigned NOT NULL DEFAULT '0',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `stream_ctime` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `index_stream_common` (`appid`,`stream_name`,`room_name`),
  KEY `index_server` (`r_ip`,`port`),
  KEY `idx_stream_list_local` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=820 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_list_watching`
--

DROP TABLE IF EXISTS `stream_list_watching`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_list_watching` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `watchr_ip` varchar(15) NOT NULL DEFAULT '',
  `port` smallint unsigned NOT NULL DEFAULT '0',
  `server_type` varchar(100) NOT NULL DEFAULT '',
  `pubip` varchar(15) NOT NULL DEFAULT '',
  `innerip` varchar(15) NOT NULL DEFAULT '',
  `webport` smallint unsigned NOT NULL DEFAULT '0',
  `appid` varchar(1000) NOT NULL DEFAULT '',
  `stream_name` varchar(1000) NOT NULL DEFAULT '',
  `room_name` varchar(1000) NOT NULL DEFAULT '',
  `roomid` varchar(1000) NOT NULL DEFAULT '',
  `uidstring` varchar(1000) NOT NULL DEFAULT '',
  `uid` varchar(1000) NOT NULL DEFAULT '',
  `session` varchar(32) NOT NULL DEFAULT '',
  `status` tinyint NOT NULL DEFAULT '0',
  `fromip` varchar(200) NOT NULL DEFAULT '',
  `bitrate` int unsigned NOT NULL DEFAULT '0',
  `bitrate_rt` int unsigned NOT NULL DEFAULT '0',
  `publish_ip` varchar(15) NOT NULL DEFAULT '',
  `publish_port` smallint NOT NULL DEFAULT '0',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `index_stream_common` (`appid`,`stream_name`,`room_name`),
  KEY `index_server` (`watchr_ip`,`port`),
  KEY `idx_stream_list_watching_status` (`status`),
  KEY `idx_stream_list_watching_servertype` (`server_type`)
) ENGINE=InnoDB AUTO_INCREMENT=16363 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_merge_logs`
--

DROP TABLE IF EXISTS `stream_merge_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_merge_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `act` tinyint NOT NULL DEFAULT '1',
  `merge_url` varchar(100) NOT NULL DEFAULT '',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `response_res` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_merge_status`
--

DROP TABLE IF EXISTS `stream_merge_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_merge_status` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `appid` varchar(100) NOT NULL DEFAULT '',
  `stream_name` varchar(100) NOT NULL DEFAULT '',
  `room_name` varchar(100) NOT NULL DEFAULT '',
  `merge_ip` varchar(15) NOT NULL DEFAULT '',
  `connected_count` int NOT NULL DEFAULT '0',
  `error_code` int NOT NULL DEFAULT '0',
  `merge_info` varchar(1000) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_stream` (`appid`,`stream_name`,`room_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs`
--

DROP TABLE IF EXISTS `stream_request_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20210914`
--

DROP TABLE IF EXISTS `stream_request_logs20210914`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20210914` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`)
) ENGINE=InnoDB AUTO_INCREMENT=37315 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211022`
--

DROP TABLE IF EXISTS `stream_request_logs20211022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211022` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211023`
--

DROP TABLE IF EXISTS `stream_request_logs20211023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211023` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211024`
--

DROP TABLE IF EXISTS `stream_request_logs20211024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211024` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211025`
--

DROP TABLE IF EXISTS `stream_request_logs20211025`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211025` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211026`
--

DROP TABLE IF EXISTS `stream_request_logs20211026`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211026` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211027`
--

DROP TABLE IF EXISTS `stream_request_logs20211027`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211027` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211028`
--

DROP TABLE IF EXISTS `stream_request_logs20211028`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211028` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211029`
--

DROP TABLE IF EXISTS `stream_request_logs20211029`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211029` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211030`
--

DROP TABLE IF EXISTS `stream_request_logs20211030`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211030` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211031`
--

DROP TABLE IF EXISTS `stream_request_logs20211031`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211031` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211101`
--

DROP TABLE IF EXISTS `stream_request_logs20211101`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211101` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211102`
--

DROP TABLE IF EXISTS `stream_request_logs20211102`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211102` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211103`
--

DROP TABLE IF EXISTS `stream_request_logs20211103`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211103` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211104`
--

DROP TABLE IF EXISTS `stream_request_logs20211104`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211104` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211105`
--

DROP TABLE IF EXISTS `stream_request_logs20211105`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211105` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211106`
--

DROP TABLE IF EXISTS `stream_request_logs20211106`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211106` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211107`
--

DROP TABLE IF EXISTS `stream_request_logs20211107`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211107` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211108`
--

DROP TABLE IF EXISTS `stream_request_logs20211108`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211108` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211109`
--

DROP TABLE IF EXISTS `stream_request_logs20211109`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211109` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211110`
--

DROP TABLE IF EXISTS `stream_request_logs20211110`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211110` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211111`
--

DROP TABLE IF EXISTS `stream_request_logs20211111`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211111` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211112`
--

DROP TABLE IF EXISTS `stream_request_logs20211112`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211112` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211113`
--

DROP TABLE IF EXISTS `stream_request_logs20211113`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211113` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211114`
--

DROP TABLE IF EXISTS `stream_request_logs20211114`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211114` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211115`
--

DROP TABLE IF EXISTS `stream_request_logs20211115`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211115` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211116`
--

DROP TABLE IF EXISTS `stream_request_logs20211116`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211116` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211117`
--

DROP TABLE IF EXISTS `stream_request_logs20211117`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211117` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211118`
--

DROP TABLE IF EXISTS `stream_request_logs20211118`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211118` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211119`
--

DROP TABLE IF EXISTS `stream_request_logs20211119`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211119` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stream_request_logs20211120`
--

DROP TABLE IF EXISTS `stream_request_logs20211120`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_request_logs20211120` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` int unsigned NOT NULL DEFAULT '0',
  `request_params` varchar(1000) NOT NULL DEFAULT '',
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `act` tinyint NOT NULL DEFAULT '0',
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session` (`session`),
  KEY `idx_stream_request_logs_streamid` (`stream_id`),
  KEY `idx_stream_request_logs_server_type` (`server_type`),
  KEY `idx_stream_request_logs_create_time` (`create_time`),
  KEY `idx_stream_request_logs_act` (`act`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_db_sync`
--

DROP TABLE IF EXISTS `test_db_sync`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_db_sync` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session` varchar(32) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85809 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-22 17:49:29
