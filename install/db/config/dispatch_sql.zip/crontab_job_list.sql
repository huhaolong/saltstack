-- MySQL dump 10.13  Distrib 8.0.26, for Linux (x86_64)
--
-- Host: localhost    Database: dispatch
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '3ec0b44f-ead5-11eb-9e9a-005056bf7f6d:1-28460255,
f84b8d75-ead5-11eb-a3bd-005056bfebb7:1-5843775';

--
-- Dumping data for table `crontab_job_list`
--

LOCK TABLES `crontab_job_list` WRITE;
/*!40000 ALTER TABLE `crontab_job_list` DISABLE KEYS */;
INSERT INTO `crontab_job_list` VALUES (1,'serviceHeartCheck',1,-1,0,0,-1,'cd /data/www/dispatch/box/shell &&  /bin/sh heartCheckHandle.sh >>  /dev/null  2>&1',0,'2021-07-23 02:13:14','2021-10-21 06:26:12'),(2,'streamHeartCheck',1,-1,0,0,-1,'cd /data/www/dispatch/box/shell  &&  /bin/sh heartCheckHandleStream.sh >>  /dev/null 2>&1',0,'2021-07-23 02:13:58','2021-10-21 06:26:11'),(3,'createLogsTables',50,23,0,0,-1,'cd /data/www/dispatch/box/job/ && php74 createLogsTables.php >> /data/logs/dispatch/createLogsTables.log 2>&1',0,'2021-07-23 02:14:26','2021-07-23 02:14:26'),(4,'deleteLogsTables',10,0,0,0,-1,'cd /data/www/dispatch/box/job && php74 deleteLogsTables.php >> /data/logs/dispatch/deleteLogsTables.log 2>&1',0,'2021-07-23 02:14:51','2021-09-15 06:09:44'),(5,'transportDataToCore',10,-1,0,0,-1,'cd /data/www/dispatch/box/job &amp;&amp; php74 transportDataHandle.php &gt;&gt; /data/logs/dispatch/transportToCore.log 2&gt;&amp;1',0,'2021-07-27 02:34:53','2021-08-19 01:45:20'),(6,'detectionJobDis',1,-1,0,0,-1,'cd /data/www/dispatch/box/shell && /bin/sh detectionJobDistribution.sh >> /dev/null 2>&1',0,'2021-08-02 08:06:41','2021-08-02 08:06:41'),(7,'pullDataFromCore',5,-1,0,0,-1,'cd /data/www/dispatch/box/job && php74 pullDataFromCore.php >> /data/logs/dispatch/pullDataFromCore.log 2>&1',0,'2021-08-10 02:39:31','2021-08-27 03:14:18'),(8,'updateNodeDataSync',6,-1,0,0,-1,'cd /data/www/dispatch/box/job &amp;&amp; php74 updateNodeDataSync.php &gt;&gt; /data/logs/dispatch/updateNodeDataSync.log 2&gt;&amp;1',0,'2021-08-10 02:39:57','2021-08-10 02:45:56'),(9,'testDbSync',1,-1,0,0,-1,'cd /data/www/dispatch/box/job && php74 dbWarn.php >> /data/logs/dispatch/dbWarn.log 2>&1',0,'2021-08-19 06:10:38','2021-09-22 08:33:00'),(10,'streamPannel',5,-1,0,0,-1,'cd /data/www/dispatch/box/job && php74 getStreamIpList.php >> /data/logs/dispatch/getStreamIpList.log 2>&1',0,'2021-08-26 09:18:42','2021-08-26 09:18:42'),(11,'serviceMonitor',1,-1,0,0,-1,'cd /data/www/dispatch/box/job && php74 serviceMonitor.php >> /data/logs/dispatch/serviceMonitor.log 2>&1',0,'2021-08-26 09:19:03','2021-10-11 02:10:27'),(12,'delErrorLog',50,22,0,0,-1,'cd /data/www/dispatch/box/job && nohup php74 delErrorLog.php >> /data/logs/dispatch/delErrorLog.log 2>&1 &',0,'2021-09-01 07:00:51','2021-10-13 01:39:59'),(13,'streamHeartPush',1,-1,0,0,-1,'cd /data/www/dispatch/box/shell && /bin/sh streamHeartPush.sh >> /dev/null 2>&1',0,'2021-10-21 07:13:41','2021-10-21 07:13:41'),(14,'queryMergeStatus',1,-1,0,0,-1,'cd /data/www/dispatch/box/shell && /bin/sh queryMergeStatus.sh >> /dev/null 2>&1',0,'2021-10-21 07:16:22','2021-10-21 07:16:22');
/*!40000 ALTER TABLE `crontab_job_list` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-22 17:51:33
